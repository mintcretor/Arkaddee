# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: b84c0f7ece2f7e66c89bc8d3ca17960b
- Android key alias: 87af0e25173c12e4049747925a999d1c
- Android key password: 6f0d77a2a1082bf17ba5e8d1974c4bde
      