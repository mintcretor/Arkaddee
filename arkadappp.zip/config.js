export const TUYA_CONFIG = {
  apiKey: '4cjhyp9xaphhpeh74r49',
  apiSecret: '81d91c57eff3419e99918792d869c5b8',
  baseUrl: 'https://openapi.tuyaus.com',
  uuid: 'az1738825079235mDp9r'
};


export const BASEAPI_CONFIG = {
  UrlImg: 'https://api.arkaddee.com',
  baseUrl: 'https://api.arkaddee.com/api',
  token: '7P2f!jQ5sH9*vL1xZ3cB8@mN6dR4tG0kY5wE2uA7pD9#oF3bV6hJ4'
};